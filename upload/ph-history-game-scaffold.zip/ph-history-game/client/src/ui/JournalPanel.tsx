interface JournalEntry {
  text: string;
  timestamp: number;
}

interface JournalPanelProps {
  entries: JournalEntry[];
  onClose: () => void;
}

export function JournalPanel({ entries, onClose }: JournalPanelProps) {
  return (
    <div className="noor-panel-overlay" onClick={onClose}>
      <div className="noor-panel" onClick={(e) => e.stopPropagation()}>
        <h2>Journal</h2>
        {entries.length === 0 && <p>Nothing written yet — explore to fill these pages.</p>}
        {entries
          .slice()
          .reverse()
          .map((entry, i) => (
            <div key={i} className="noor-journal-entry">
              {entry.text}
            </div>
          ))}
        <button className="noor-button" onClick={onClose}>
          Close
        </button>
      </div>
    </div>
  );
}
