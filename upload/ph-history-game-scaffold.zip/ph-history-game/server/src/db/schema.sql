-- Project Noor — starter schema. See Master Prompt Sections 17 & 19.

CREATE TABLE IF NOT EXISTS users (
  id            SERIAL PRIMARY KEY,
  username      VARCHAR(50) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS save_slots (
  id                SERIAL PRIMARY KEY,
  user_id           INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  slot_number       SMALLINT NOT NULL CHECK (slot_number BETWEEN 1 AND 3),
  current_chapter_id VARCHAR(50) NOT NULL DEFAULT 'prologue',
  knowledge_xp      INTEGER NOT NULL DEFAULT 0,
  medal_count       INTEGER NOT NULL DEFAULT 0,
  playtime_seconds  INTEGER NOT NULL DEFAULT 0,
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, slot_number)
);

CREATE TABLE IF NOT EXISTS codex_progress (
  id            SERIAL PRIMARY KEY,
  save_slot_id  INTEGER NOT NULL REFERENCES save_slots(id) ON DELETE CASCADE,
  codex_entry_id VARCHAR(100) NOT NULL,
  unlocked_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (save_slot_id, codex_entry_id)
);

CREATE TABLE IF NOT EXISTS journal_entries (
  id           SERIAL PRIMARY KEY,
  save_slot_id INTEGER NOT NULL REFERENCES save_slots(id) ON DELETE CASCADE,
  chapter_id   VARCHAR(50),
  text         TEXT NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS achievements (
  id           SERIAL PRIMARY KEY,
  save_slot_id INTEGER NOT NULL REFERENCES save_slots(id) ON DELETE CASCADE,
  achievement_id VARCHAR(100) NOT NULL,
  unlocked_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (save_slot_id, achievement_id)
);
