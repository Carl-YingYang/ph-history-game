import { useState } from 'react';

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  footnote: string;
}

interface QuizModalProps {
  questions: QuizQuestion[];
  onComplete: () => void;
}

export function QuizModal({ questions, onComplete }: QuizModalProps) {
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);

  const q = questions[index];
  const isLast = index === questions.length - 1;

  function choose(i: number) {
    if (selected !== null) return;
    setSelected(i);
  }

  function next() {
    if (isLast) {
      onComplete();
      return;
    }
    setIndex(index + 1);
    setSelected(null);
  }

  return (
    <div className="noor-panel-overlay">
      <div className="noor-panel">
        <h2>Journal Recap — how much do you remember?</h2>
        <div className="noor-quiz-question">{q.question}</div>
        {q.options.map((opt, i) => (
          <button key={i} className="noor-quiz-option" onClick={() => choose(i)}>
            {opt}
            {selected !== null && i === q.correctIndex ? '  ✓' : ''}
          </button>
        ))}
        {selected !== null && (
          <div style={{ marginTop: 12, fontSize: 13, color: '#cfcfcf' }}>
            <strong>Here's what actually happened:</strong> {q.footnote}
          </div>
        )}
        {selected !== null && (
          <button className="noor-button" style={{ marginTop: 12 }} onClick={next}>
            {isLast ? 'Finish' : 'Next'}
          </button>
        )}
      </div>
    </div>
  );
}
