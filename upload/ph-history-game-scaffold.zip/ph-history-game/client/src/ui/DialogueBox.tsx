interface DialogueBoxProps {
  speaker: string;
  line: string;
}

export function DialogueBox({ speaker, line }: DialogueBoxProps) {
  if (!line) return null;
  return (
    <div className="noor-dialogue-box">
      <div className="noor-dialogue-speaker">{speaker}</div>
      <div>{line}</div>
    </div>
  );
}
