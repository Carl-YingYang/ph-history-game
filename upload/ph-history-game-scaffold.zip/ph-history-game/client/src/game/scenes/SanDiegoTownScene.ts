import Phaser from 'phaser';
import { GameEvents } from '../config';
import { getQuestsForChapter } from '../data/quests';

/**
 * San Diego Town Plaza — the Chapter 1 hub area (Master Prompt Section 7/8).
 * Minimal top-down movement + a single talkable NPC (Mang Tenyo) as a
 * template for wiring more NPCs/dialogue/quests in later build passes.
 */
export class SanDiegoTownScene extends Phaser.Scene {
  private player!: Phaser.Physics.Arcade.Sprite;
  private npc!: Phaser.Physics.Arcade.Sprite;
  private cursors!: Phaser.Types.Input.Keyboard.CursorKeys;
  private hasTalkedToNpc = false;

  constructor() {
    super('SanDiegoTownScene');
  }

  create() {
    this.add.image(400, 300, 'floor-town');
    this.add
      .text(400, 30, 'San Diego — Town Plaza, 1887', {
        fontFamily: 'Georgia, serif',
        fontSize: '20px',
        color: '#f2e8d5',
      })
      .setOrigin(0.5);

    this.player = this.physics.add.sprite(400, 450, 'player');
    this.player.setCollideWorldBounds(true);

    this.npc = this.physics.add.sprite(400, 250, 'npc');
    this.add
      .text(400, 220, 'Mang Tenyo', { fontFamily: 'Georgia, serif', fontSize: '13px', color: '#ffd27a' })
      .setOrigin(0.5);

    this.physics.add.overlap(this.player, this.npc, () => this.tryTalkToNpc());

    this.cursors = this.input.keyboard!.createCursorKeys();

    const questsHere = getQuestsForChapter('ch1');
    this.add
      .text(20, 560, `Chapter 1 quests loaded: ${questsHere.length}`, {
        fontFamily: 'monospace',
        fontSize: '12px',
        color: '#888',
      })
      .setOrigin(0);
  }

  update() {
    const speed = 160;
    this.player.setVelocity(0);
    if (this.cursors.left?.isDown) this.player.setVelocityX(-speed);
    else if (this.cursors.right?.isDown) this.player.setVelocityX(speed);
    if (this.cursors.up?.isDown) this.player.setVelocityY(-speed);
    else if (this.cursors.down?.isDown) this.player.setVelocityY(speed);
  }

  private tryTalkToNpc() {
    if (this.hasTalkedToNpc) return;
    this.hasTalkedToNpc = true;

    this.game.events.emit(GameEvents.DialogueLine, {
      speaker: 'Mang Tenyo',
      line: "You're not from around here, iho — best not to mention the Ibarra name too loudly tonight.",
    });

    this.game.events.emit(GameEvents.JournalEntry, {
      text: 'Mang Tenyo warned me not to mention the Ibarra name loudly. Something happened at last night\u2019s reception.',
    });

    this.game.events.emit(GameEvents.CodexUnlock, { id: 'char.ibarra' });
    this.game.events.emit(GameEvents.CodexUnlock, { id: 'char.tiago' });
    this.game.events.emit(GameEvents.KnowledgeXp, { amount: 60, reason: 'mq.ch1.arrival' });
  }
}
