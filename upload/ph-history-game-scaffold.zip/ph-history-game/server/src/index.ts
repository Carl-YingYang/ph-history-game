import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { authRouter } from './routes/auth';
import { progressRouter } from './routes/progress';
import { codexRouter } from './routes/codex';

const app = express();

app.use(cors({ origin: process.env.CLIENT_ORIGIN ?? 'http://localhost:5173' }));
app.use(express.json());

app.get('/api/health', (_req, res) => res.json({ ok: true, project: 'ph-history-game' }));
app.use('/api/auth', authRouter);
app.use('/api/progress', progressRouter);
app.use('/api/codex', codexRouter);

const port = Number(process.env.PORT) || 4000;
app.listen(port, () => {
  console.log(`[server] Project Noor API listening on http://localhost:${port}`);
});
