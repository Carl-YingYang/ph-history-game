# Project Noor — Rizal-Inspired Educational RPG

A Pokémon-style top-down RPG where the player witnesses the events of José Rizal's
*Noli Me Tangere* and *El Filibusterismo* as a time-displaced 2026 college student.

See **[`RIZAL_RPG_MASTER_PROMPT.md`](./RIZAL_RPG_MASTER_PROMPT.md)** for the full design
document — that file is the single source of truth for every system in this repo.
Feed it to an AI coding session (Claude Code, Cursor, etc.) as project context whenever
you continue building.

## Stack

- **Client:** React + TypeScript + Vite, with Phaser 3 mounted inside a React shell
- **Server:** Node.js + Express + TypeScript, PostgreSQL, JWT auth
- **Assets:** drop your art/audio into `client/public/assets/` following the folder
  contract in the Master Prompt, Section 22

## Quick start

### Client
```bash
cd client
npm install
npm run dev       # http://localhost:5173
```

### Server
```bash
cd server
cp .env.example .env   # fill in your Postgres connection string + JWT secret
npm install
npm run db:init        # runs src/db/schema.sql against your Postgres
npm run dev            # http://localhost:4000
```

## Repo layout

```
client/   React + Phaser game client (see client/README notes inline in source)
server/   Express + Postgres + JWT API (auth, save progress, codex unlocks)
RIZAL_RPG_MASTER_PROMPT.md   full GDD / build prompt
```

## Current build status

This is **Phase 0 (Foundation)** per the roadmap in the Master Prompt: repo scaffold,
a playable Prologue → "wake up in 1887" scene, the Codex/Chapter/Quest data pipeline,
and a working save/load + JWT auth round-trip against Postgres. Placeholder colored
rectangles stand in for sprites so nothing blocks on missing art — swap them out via
`client/src/game/data/*.ts` and the asset folders under `client/public/assets/`.

Next steps are listed in Section 24 of the Master Prompt.
