import { Router } from 'express';

// Codex reference data currently lives client-side in
// client/src/game/data/codex.ts (kept there so it can be typed/authored
// alongside chapters.ts and quests.ts — see Master Prompt Section 19).
// This route is a placeholder for once that data is promoted server-side
// (e.g. for a future Teacher Dashboard, Master Prompt Section 25).
export const codexRouter = Router();

codexRouter.get('/health', (_req, res) => {
  res.json({ ok: true, note: 'Codex reference data currently ships with the client bundle.' });
});
