import { codexEntries, CodexCategory } from '../game/data/codex';

interface CodexPanelProps {
  unlockedIds: Set<string>;
  onClose: () => void;
}

const CATEGORY_LABELS: Record<CodexCategory, string> = {
  characters: 'Characters',
  locations: 'Locations',
  terms: 'Historical Terms',
  booksAndLetters: 'Books & Letters',
  events: 'Events',
  timeline: 'Timeline',
  artifacts: 'Artifacts',
  vocabulary: 'Vocabulary',
};

export function CodexPanel({ unlockedIds, onClose }: CodexPanelProps) {
  const categories = Object.keys(CATEGORY_LABELS) as CodexCategory[];

  return (
    <div className="noor-panel-overlay" onClick={onClose}>
      <div className="noor-panel" onClick={(e) => e.stopPropagation()}>
        <h2>Rizal Codex</h2>
        {categories.map((cat) => {
          const entries = codexEntries.filter((e) => e.category === cat);
          if (entries.length === 0) return null;
          return (
            <div key={cat} style={{ marginBottom: 16 }}>
              <h3 style={{ fontSize: 14, color: '#d9b26a' }}>{CATEGORY_LABELS[cat]}</h3>
              <div className="noor-codex-grid">
                {entries.map((entry) => {
                  const unlocked = unlockedIds.has(entry.id);
                  return (
                    <div key={entry.id} className={`noor-codex-card ${unlocked ? '' : 'locked'}`}>
                      <div className={entry.kind === 'historical' ? 'noor-tag-historical' : 'noor-tag-fictional'}>
                        {entry.kind === 'historical' ? 'HISTORICAL FIGURE/EVENT' : "FICTIONAL — RIZAL'S CREATION"}
                      </div>
                      <strong>{unlocked ? entry.name : '???'}</strong>
                      <div>{unlocked ? entry.summary : 'Not yet discovered.'}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
        <button className="noor-button" onClick={onClose}>
          Close
        </button>
      </div>
    </div>
  );
}
