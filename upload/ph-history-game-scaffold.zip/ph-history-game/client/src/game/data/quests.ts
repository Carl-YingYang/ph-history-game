// Quest definitions. See Master Prompt Section 10 for the full template
// and design rationale. Extend per-chapter as content is built out.

export type QuestType = 'main' | 'side' | 'knowledge' | 'collectible';

export interface Quest {
  id: string;
  type: QuestType;
  chapterId: string;
  title: string;
  storyPurpose: string;
  learningObjective: string;
  npcIds: string[];
  objectives: string[];
  rewardXp: number;
  codexUnlockIds: string[];
  historicalExplanation: string;
}

export const quests: Quest[] = [
  {
    id: 'mq.ch1.arrival',
    type: 'main',
    chapterId: 'ch1',
    title: "A Stranger's Welcome",
    storyPurpose: "Establish the player's cover identity and introduce San Diego.",
    learningObjective: "Ibarra's homecoming after seven years studying in Europe, and the social tension it creates.",
    npcIds: ['mang-tenyo', 'char.tiago'],
    objectives: [
      'Follow Mang Tenyo into town',
      'Overhear the reception gossip from the kitchen staff',
      'Meet Ibarra briefly in the plaza the next morning',
    ],
    rewardXp: 60,
    codexUnlockIds: ['char.ibarra', 'char.tiago', 'char.damaso'],
    historicalExplanation:
      'Ilustrados like Ibarra (and Rizal himself) often returned from European study to a colonial society deeply suspicious of the reformist ideas they brought back.',
  },
  {
    id: 'sq.ch3.tasyo-library',
    type: 'side',
    chapterId: 'ch3',
    title: "What Tasyo Reads at Night",
    storyPurpose: 'Deepen understanding of why Pilosopo Tasyo is dismissed as "loco" by San Diego.',
    learningObjective:
      "19th-century ilustrados' access to banned Enlightenment texts, and the social cost of intellectualism under friar-controlled information.",
    npcIds: ['char.tasyo'],
    objectives: [
      'Overhear two vendors gossiping about "the old fool\'s books"',
      "Visit Tasyo's hut and ask about his library",
      'Choose a follow-up question (cosmetic branching only)',
    ],
    rewardXp: 40,
    codexUnlockIds: ['char.tasyo'],
    historicalExplanation:
      'Owning certain banned books was itself politically dangerous in colonial Philippines — a risk real Propaganda Movement figures took.',
  },
  {
    id: 'kq.ch1.codex-intro',
    type: 'knowledge',
    chapterId: 'ch1',
    title: 'Your First Entry',
    storyPurpose: 'Onboard the player to the Codex/Journal systems.',
    learningObjective: 'How the Rizal Codex is organized (Characters, Locations, Terms, etc.)',
    npcIds: [],
    objectives: ['Open the Codex from the pause menu', 'Read your first unlocked entry'],
    rewardXp: 20,
    codexUnlockIds: [],
    historicalExplanation: '',
  },
  {
    id: 'cq.ch3.pressed-flower',
    type: 'collectible',
    chapterId: 'ch3',
    title: 'A Pressed Sampaguita',
    storyPurpose: "A small keepsake tying the player to Maria Clara's garden.",
    learningObjective: 'Sampaguita as a recurring national/cultural symbol in Filipino literature.',
    npcIds: [],
    objectives: ['Find the pressed flower hidden near the garden trellis'],
    rewardXp: 15,
    codexUnlockIds: [],
    historicalExplanation: 'The sampaguita later became the Philippines\u2019 national flower (declared in 1934).',
  },
];

export function getQuestsForChapter(chapterId: string): Quest[] {
  return quests.filter((q) => q.chapterId === chapterId);
}
