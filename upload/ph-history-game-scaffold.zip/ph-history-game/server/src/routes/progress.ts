import { Router } from 'express';
import { pool } from '../db/pool';
import { AuthedRequest, requireAuth } from '../middleware/auth';

export const progressRouter = Router();
progressRouter.use(requireAuth);

// GET /api/progress/:slot — load a save slot (chapter, xp, medals, codex, journal)
progressRouter.get('/:slot', async (req: AuthedRequest, res) => {
  const slot = Number(req.params.slot);
  const save = await pool.query(
    'SELECT * FROM save_slots WHERE user_id = $1 AND slot_number = $2',
    [req.userId, slot]
  );
  if (save.rows.length === 0) return res.status(404).json({ error: 'No save in this slot' });

  const saveSlotId = save.rows[0].id;
  const [codex, journal] = await Promise.all([
    pool.query('SELECT codex_entry_id FROM codex_progress WHERE save_slot_id = $1', [saveSlotId]),
    pool.query('SELECT chapter_id, text, created_at FROM journal_entries WHERE save_slot_id = $1 ORDER BY created_at', [
      saveSlotId,
    ]),
  ]);

  res.json({
    save: save.rows[0],
    unlockedCodexIds: codex.rows.map((r) => r.codex_entry_id),
    journalEntries: journal.rows,
  });
});

// PUT /api/progress/:slot — upsert chapter/xp/medal progress
progressRouter.put('/:slot', async (req: AuthedRequest, res) => {
  const slot = Number(req.params.slot);
  const { currentChapterId, knowledgeXp, medalCount, playtimeSeconds } = req.body ?? {};

  const result = await pool.query(
    `INSERT INTO save_slots (user_id, slot_number, current_chapter_id, knowledge_xp, medal_count, playtime_seconds)
     VALUES ($1, $2, $3, $4, $5, $6)
     ON CONFLICT (user_id, slot_number)
     DO UPDATE SET current_chapter_id = $3, knowledge_xp = $4, medal_count = $5, playtime_seconds = $6, updated_at = now()
     RETURNING *`,
    [req.userId, slot, currentChapterId ?? 'prologue', knowledgeXp ?? 0, medalCount ?? 0, playtimeSeconds ?? 0]
  );
  res.json(result.rows[0]);
});

// POST /api/progress/:slot/codex — unlock a codex entry
progressRouter.post('/:slot/codex', async (req: AuthedRequest, res) => {
  const slot = Number(req.params.slot);
  const { codexEntryId } = req.body ?? {};
  if (!codexEntryId) return res.status(400).json({ error: 'codexEntryId required' });

  const save = await pool.query('SELECT id FROM save_slots WHERE user_id = $1 AND slot_number = $2', [
    req.userId,
    slot,
  ]);
  if (save.rows.length === 0) return res.status(404).json({ error: 'No save in this slot' });

  await pool.query(
    'INSERT INTO codex_progress (save_slot_id, codex_entry_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
    [save.rows[0].id, codexEntryId]
  );
  res.status(201).json({ ok: true });
});

// POST /api/progress/:slot/journal — append a journal entry
progressRouter.post('/:slot/journal', async (req: AuthedRequest, res) => {
  const slot = Number(req.params.slot);
  const { chapterId, text } = req.body ?? {};
  if (!text) return res.status(400).json({ error: 'text required' });

  const save = await pool.query('SELECT id FROM save_slots WHERE user_id = $1 AND slot_number = $2', [
    req.userId,
    slot,
  ]);
  if (save.rows.length === 0) return res.status(404).json({ error: 'No save in this slot' });

  const inserted = await pool.query(
    'INSERT INTO journal_entries (save_slot_id, chapter_id, text) VALUES ($1, $2, $3) RETURNING *',
    [save.rows[0].id, chapterId ?? null, text]
  );
  res.status(201).json(inserted.rows[0]);
});
