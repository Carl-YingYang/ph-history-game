import Phaser from 'phaser';

/**
 * BootScene generates simple colored-rectangle placeholder textures so the
 * game is fully playable before real sprite sheets are dropped into
 * client/public/assets/ (see Master Prompt Section 22 for the asset contract).
 * Replace `makePlaceholder` calls with `this.load.spritesheet(...)` once art lands.
 */
export class BootScene extends Phaser.Scene {
  constructor() {
    super('BootScene');
  }

  preload() {
    this.makePlaceholder('player', 0x8fd3ff, 32, 32);
    this.makePlaceholder('npc', 0xffd27a, 32, 32);
    this.makePlaceholder('floor-library', 0x2b2b3a, 800, 600);
    this.makePlaceholder('floor-town', 0x3a3222, 800, 600);
    this.makePlaceholder('book', 0x7a4a2b, 24, 32);
    this.makePlaceholder('letter', 0xf2e8d5, 28, 20);
  }

  create() {
    this.scene.start('PrologueScene');
  }

  private makePlaceholder(key: string, color: number, w: number, h: number) {
    const g = this.make.graphics({ x: 0, y: 0 });
    g.fillStyle(color, 1);
    g.fillRect(0, 0, w, h);
    g.lineStyle(2, 0x000000, 0.35);
    g.strokeRect(0, 0, w, h);
    g.generateTexture(key, w, h);
    g.destroy();
  }
}
