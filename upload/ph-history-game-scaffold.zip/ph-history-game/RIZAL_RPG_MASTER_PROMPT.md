# PROJECT NOOR: THE UNFINISHED DAWN
### Master Design & Build Prompt — Rizal-Inspired Educational RPG
*(Working title used below: "Project Noor." Rename freely — "noor" nods to "the dawn Elias never saw.")*

> **How to use this document:** This is the single source of truth for the project. Paste this whole file as the system/project prompt for any AI coding session (Claude Code, Cursor, etc.), or hand it to a human dev team as the GDD. It replaces and supersedes the original loose prompt — every requirement from that prompt is preserved below, but disambiguated, sequenced, and grounded in the *actual* plot of Noli Me Tangere and El Filibusterismo so nothing has to be invented from scratch mid-build.

---

## 0. EXECUTIVE SUMMARY

**Project Noor** is a 2D top-down pixel RPG that plays like a Pokémon-generation handheld game (Gen 3–5 feel, Coromon/Nexomon-adjacent UX) but replaces monster-catching/battling with **witnessing and documenting Philippine history**. The player is a 2026 college student pulled through a mysterious letter into San Diego, 1887 — the fictional town of *Noli Me Tangere* — and later into the Manila of *El Filibusterismo*, 1891. They cannot change what happens to Ibarra, Elias, Sisa, Maria Clara, or Simoun. They can only explore, ask questions, solve puzzles, and record what they witness in a **Rizal Codex** — becoming, by the end, an *Illustrado*: someone who truly understands.

- **Engine:** Phaser 3 (game canvas) inside **React + TypeScript** (shell/UI/menus)
- **Backend:** Node.js + Express, **PostgreSQL**, **JWT** auth
- **Platforms:** Web (primary), Desktop wrapper later (Tauri/Electron), Mobile after that
- **Tone target:** All-ages, roughly a "T for Teen" equivalent — the novels contain death, abuse, and sexual menace; Section 21 below defines exactly how much of that is shown vs. narrated.

---

## 1. VISION STATEMENT

> *"Noli Me Tangere and El Filibusterismo are usually assigned as homework. Project Noor is designed so that a 15-year-old finishes it having voluntarily reread Rizal's footnotes — not because they were tested, but because they were there."*

The game must never feel like edutainment filler bolted onto a quiz. Every mechanic borrowed from Pokémon exists because it already teaches a habit the game needs (curiosity about hidden areas, talking to every NPC, completing a "dex," caring about a badge/medal count). We are reusing a proven **behavioral loop**, not just an aesthetic.

---

## 2. GAME PILLARS

1. **Witness, Don't Rewrite** — Player agency is exploratory and interpretive, never plot-altering. Side quests can help minor/invented NPCs; they never save Elias, un-imprison Sisa, or stop the execution. This is a design pillar, not a limitation — the tragedy landing on schedule *is* the theme (see Padre Florentino's thesis in Section 21).
2. **Curiosity Is the Currency** — Replace "grinding EXP off wild encounters" with "grinding Knowledge XP off curiosity" (reading signs, opening books, asking a fourth follow-up question).
3. **The Codex Is the Real Endgame** — Like a Pokédex completion run, 100%-ing the Rizal Codex is the long-tail goal for replay-minded players.
4. **Two Novels, One Emotional Arc** — Noli's hope must curdle into Fili's cynicism *mechanically*, not just narratively (see Section 9, tone-shift techniques).
5. **Respectful of the Source** — Historical figures (Rizal himself) are never playable, never given invented dialogue that contradicts the historical record, and never trivialized. Fictional characters (Ibarra, Simoun, Elias, etc.) have full creative latitude since they're Rizal's own inventions.

---

## 3. TARGET AUDIENCE

| Segment | Why they play | Design implication |
|---|---|---|
| Filipino Grade 9–10 students (Noli/Fili are in the DepEd curriculum) | Assigned reading companion | Codex entries must double as legitimate study notes; quiz content must be curriculum-safe/accurate |
| Filipino college students & young professionals | Nostalgia, "I wish I had this in high school" | Deeper lore, harder puzzles, unlockable historian-level Codex tier |
| Diaspora Filipinos | Reconnect with heritage, teach their kids | Optional English-first dialogue toggle (see Section 12) |
| General JRPG/Pokémon fans (non-Filipino) | Genre familiarity | The Prologue must fully onboard someone with zero Rizal knowledge in <10 minutes |

---

## 4. CORE CONCEPT / PREMISE

**Cold open (Prologue, ~10–15 min):**

```
University Library (2026, present-day Manila)
   ↓  Player, a nameless/customizable student, is shelving/returning
   ↓  a copy of Noli Me Tangere for a class requirement.
   ↓
A brittle, handwritten letter falls out of the book.
It's addressed "To whoever still remembers —"
   ↓
Player reads the letter (first real player-chosen dialogue: curious /
skeptical / dismissive tone — cosmetic only, tracked as a minor Codex flag)
   ↓
The library goes silent. Pages of every book on the shelf begin to glow.
   ↓
BLACKOUT
   ↓
Player wakes up face-down in a rice paddy outside San Diego, 1887.
Distant church bells. A cart driver (invented NPC, "Mang Tenyo")
finds them and assumes they're a new teacher's aide from Manila —
this becomes the player's cover identity for the whole Noli arc.
```

This cover identity (a "visiting scholar's aide") is important: it's the diegetic reason NPCs talk to a stranger, the reason the player can wander a church, a school construction site, and a principal household without suspicion, and it foreshadows the player's real function — a chronicler, same as Rizal was.

The player is **never** Ibarra, Elias, or Simoun. They are always themselves, an observer with a name the player picks, referred to by NPCs as "iho/iha" (son/daughter) or "ka-eskwela" (fellow student) depending on region/chapter.

---

## 5. DESIGN PHILOSOPHY — THE POKÉMON MAPPING TABLE

| Pokémon concept | Project Noor equivalent | Notes |
|---|---|---|
| Pokémon Center | **School Library / Convent Archive** | Heals nothing (no HP) — instead refills a "Focus" meter used for puzzle mini-games, and is the fast-travel/save anchor |
| Poké Mart | **Bookstore / Sari-sari Store** | Sells cosmetic outfit pieces, journal stickers/stamps, hint tokens |
| Pokédex | **Rizal Codex** | Full spec in Section 15 |
| Wild encounters / battles | **Historical Investigation Encounters** | Replaces battle triggers: an NPC flags a mystery (a rumor, a hidden object, a contradiction between two testimonies); player "resolves" it via dialogue-tree or mini-game, not combat |
| EXP / Levels | **Knowledge XP / Ranks** | Section 13 |
| Gym Badges | **Chapter Medals** | Awarded at the end of each Gameplay Chapter (Section 8) |
| HMs (Cut, Surf...) | **Historical Documents** | E.g., obtaining Fr. Dámaso's sermon notes lets you enter the sacristy; a merchant's ledger lets you cross the river checkpoint. Functions exactly like an HM key-item gate. |
| Evolution | **Character Understanding Milestones** | The *player's* Codex entry on a character "evolves" (more portrait detail, deeper bio) as the player learns more about them — Rizal's characters don't evolve, the player's understanding of them does |
| Trainer rival | **"Ka-Estudyante" — a fellow modern-day exchange student** (invented character, optional) | A rival who has already read the book and needles the player with foreshadowing; recurring comic-relief + soft hint system |
| Region map | **World Map, Section 7** | |

---

## 6. CORE GAMEPLAY LOOP

```
 ┌─────────────────────────────────────────────────────────────────┐
 │  EXPLORE AREA                                                    │
 │      ↓                                                           │
 │  TALK TO NPC(s)  ───────────────►  (optional) ACCEPT SIDE QUEST  │
 │      ↓                                                                 ↓
 │  TRIGGER MAIN STORY BEAT (scripted, unskippable, witnessed only) │
 │      ↓                                                           │
 │  SOLVE ENVIRONMENTAL PUZZLE / MINI-GAME (ties to the beat)       │
 │      ↓                                                           │
 │  HISTORICAL CONTEXT POP-UP  (short, skippable-after-first-read,  │
 │     footnote-style, never blocks re-reading later via Codex)     │
 │      ↓                                                           │
 │  STORY EVENT RESOLVES                                            │
 │      ↓                                                           │
 │  MINI QUIZ (2–4 Qs, framed as the player's own journal recap —   │
 │     never a "test," always "what do YOU remember?")              │
 │      ↓                                                           │
 │  KNOWLEDGE XP + JOURNAL AUTO-ENTRY + CODEX UNLOCK(S)              │
 │      ↓                                                           │
 │  (end of chapter) CHAPTER MEDAL + SAVE CHECKPOINT                 │
 │      ↓                                                           │
 │  NEXT CHAPTER GATE OPENS                                          │
 └─────────────────────────────────────────────────────────────────┘
```

---

## 7. WORLD DESIGN & MAP

Semi-open like Pokémon Gen 3: hub-and-spoke areas gated by story flags/"Historical Documents," not levels.

```
                         ┌────────────────────┐
                         │  UNIVERSITY LIBRARY │  (2026 frame — bookend area)
                         └──────────┬─────────┘
                                    │ (letter / time-fall)
                         ┌──────────▼─────────┐
                         │   RICE PADDY OUTSKIRTS│ (Prologue landing zone)
                         └──────────┬─────────┘
                                    │
                    ┌───────────────▼────────────────┐
                    │         SAN DIEGO (HUB)         │
                    │  ┌───────────┬────────────────┐ │
                    │  │ Town Plaza│  Church &       │ │
                    │  │ & Market  │  Convent        │ │
                    │  ├───────────┼────────────────┤ │
                    │  │ Ibarra    │  School         │ │
                    │  │ Mansion   │  Construction   │ │
                    │  │           │  Site           │ │
                    │  ├───────────┴────────────────┤ │
                    │  │  Cap. Tiago / Maria Clara    │ │
                    │  │  Household                   │ │
                    │  └──────────────────────────────┘ │
                    └───┬─────────────┬──────────────┬──┘
                        │             │              │
              ┌─────────▼───┐  ┌──────▼──────┐ ┌─────▼──────┐
              │ LAGUNA DE BAY│  │  FOREST PATH │ │  ROAD TO   │
              │ (picnic,     │  │ (Tasyo's hut,│ │  MANILA    │
              │  crocodile,  │  │  Sisa's      │ │  (port)    │
              │  boat chase) │  │  wandering,  │ └─────┬──────┘
              └─────────┬────┘  │  Elias'      │       │
                        │       │  grandfather's│       │
              ┌─────────▼────┐  │  tomb)        │       │
              │ ELIAS HIDEOUT│  └──────┬───────┘       │
              │ (late-game,  │         │               │
              │  optional)   │  ┌──────▼───────┐        │
              └──────────────┘  │ ENDING OF NOLI│        │
                                 │ (lake chase,  │        │
                                 │  cutscene-only│        │
                                 │  — see 8.1)   │        │
                                 └──────┬───────┘        │
                                        │                │
                              ═════ TIME SKIP (13 yrs) ═══▼════
                                        │
                         ┌──────────────▼───────────────┐
                         │   STEAMSHIP "TABO" (Pasig R.) │  (Fili opens here —
                         │   upper deck / lower deck      │   class-divide tutorial)
                         └──────────────┬────────────────┘
                                        │
                    ┌───────────────────▼────────────────────┐
                    │              MANILA (HUB)                │
                    │ ┌───────────┬───────────┬──────────────┐ │
                    │ │ UST        │ Quiapo Fair│ Quiroga's   │ │
                    │ │ (Univ. of  │ (Sphinx     │ Bazaar      │ │
                    │ │ Sto. Tomas)│  exhibit)   │ (arms front)│ │
                    │ ├───────────┴───────────┴──────────────┤ │
                    │ │  Capitan Tiago's House (wedding venue) │ │
                    │ └────────────────────────────────────────┘ │
                    └───┬──────────────────────────────────┬────┘
                         │                                  │
               ┌─────────▼─────────┐              ┌─────────▼─────────┐
               │  SAN DIEGO REVISIT│              │  TALES' FARM /     │
               │  (Sisa's grave,   │              │  BANDIT MOUNTAINS  │
               │  Basilio's return)│              │  (Cabesang Tales   │
               └───────────────────┘              │  arc, cutscene-    │
                                                    │  heavy, see 8.2)  │
                                                    └───────────────────┘
                                        │
                         ┌──────────────▼───────────────┐
                         │  PADRE FLORENTINO'S COASTAL   │
                         │  ESTATE  (finale)             │
                         └──────────────┬────────────────┘
                                        │
                         ┌──────────────▼───────────────┐
                         │  UNIVERSITY LIBRARY, 2026     │  (bookend closes)
                         └───────────────────────────────┘
```

Every named building has a stated gameplay purpose (Section 8 gives it per-chapter; no "empty houses" — Rizal's world already supplies more real locations than a first game needs).

---

## 8. CHAPTER DESIGN (GAMEPLAY CHAPTERS, NOT BOOK CHAPTERS)

11 gameplay chapters total (7 Noli, 1 time-skip interstitial, 3 Fili) plus Prologue and Epilogue. Each ends with the loop in Section 6.

### 8.1 NOLI ARC

| # | Chapter Title | Real Novel Events Covered | Player Verbs | Chapter Medal |
|---|---|---|---|---|
| P | *The Letter* (Prologue) | Frame story only | Read, walk, talk | — |
| 1 | *A Stranger in San Diego* | Arrival; meeting Ibarra fresh off the boat from Europe; the reception dinner is *heard about*, not attended (player is too low-status) — instead player pieces it together from servant gossip | Eavesdrop, ask NPCs, Codex: unlock Ibarra, Cap. Tiago, Fr. Dámaso | **Medal: Listener** |
| 2 | *The Fair-Weather Friend* | Lt. Guevara reveals Don Rafael's fate (slander, prison death, exhumation) | Investigate the old Ibarra estate records, dialogue with Guevara, first "Historical Investigation Encounter" | **Medal: The Ledger** |
| 3 | *The School on the Hill* | Ibarra's school project; consulting Pilosopo Tasyo; the Laguna de Bay picnic & crocodile attack; player is a bystander who fetches help while Ibarra saves Elias | Puzzle: net-tangle minigame (see Section 20); Codex: unlock Elias, Tasyo, Maria Clara's friend group | **Medal: The Cornerstone** |
| 4 | *The Derrick and the Feast* | Assassination attempt at the cornerstone-laying; the luncheon; Dámaso's tirade; Ibarra's public breakdown & excommunication | Timed "warn the townspeople" sequence sourced from Elias's tip; witness-only cutscene for the confrontation (no player combat) | **Medal: The Broken Toast** |
| 5 | *Sisa's Song* | Crispin/Basilio's persecution, Sisa's arrest and madness | Side-quest chain following Basilio's escape from a distance; player can leave bread/find him supplies but cannot save Crispin (fixed outcome) | **Medal: The Empty Chair** |
| 6 | *The Uprising That Wasn't* | Lucas/Salví's fake rebellion frame-up; Ibarra's arrest; Maria Clara's forced betrayal (the letters) | Investigation minigame: player assembles the frame-up from scattered clues *after the fact* — dramatic irony, since the player already watched it happen | **Medal: The Forged Signature** |
| 7 | *Across the Lake* | Elias's jailbreak of Ibarra, the mansion burning, the boat chase, Elias's death monologue, Sisa's death, Maria Clara's cloistering | Fully cutscene-driven (this is the emotional climax — see 8.3 tone notes); final QTE-free "row silently" sequence; Elias's "*I shall die without seeing the dawn...*" line is paraphrased/adapted, not reproduced verbatim (see Section 21 legal note) | **Medal: The Unfinished Dawn** *(hence the working title)* |

### 8.2 INTERSTITIAL

| I | *Thirteen Years* | Time-skip. A short, book-ended sequence: player returns to the 2026 library for a scene, ages/context update, then falls back in — now aboard the steamship Tabo | Dialogue-only, sets up Fili's tonal shift | **Medal: The Long Silence** |

### 8.3 FILI ARC

| # | Chapter Title | Real Novel Events Covered | Player Verbs | Chapter Medal |
|---|---|---|---|---|
| 8 | *Upper Deck, Lower Deck* | Steamship class divide; meeting Simoun (unaware he's Ibarra); Basilio as a med student; Cabesang Tales' backstory told in flashback fragments | "Two decks" traversal mechanic — literal verticality used to teach colonial class structure | **Medal: The Dividing Line** |
| 9 | *The Academy and the Sphinx* | Student petition for a Spanish academy; UST classroom humiliation; Quiapo Fair Sphinx exhibit; poster crackdown; Basilio's imprisonment; Juli's fate (handled per Section 21) | Puzzle: Letter Assembly (reconstructing the anti-clerical posters' real authorship to clear an innocent NPC); Codex: unlock Isagani, Simoun's true identity | **Medal: The Silenced Press** |
| 10 | *The Lamp* | Cabesang Tales/Matanglawin's parallel tragedy; the wedding, the nitroglycerin lamp, Isagani's last-second save, Tales' death by his own son's hand | Timeline Arrangement minigame reconstructing Tales' fall from farmer to "Matanglawin"; finale is cutscene-only (no player control of the bomb) | **Medal: The Pomegranate Lamp** |
| 11 | *Padre Florentino's Shore* | Simoun's confession, Florentino's civic-virtue rebuttal, the jewels thrown into the sea | Dialogue-choice reflection sequence — the *player*, not Simoun, answers Florentino's closing question, feeding directly into the Ending's "Player Reflection Journal" | **Medal: The Sea That Keeps Them** |
| E | *Epilogue: Bagumbayan* | Rizal's historical execution, Dec 30, 1896 (real biography, not novel-fiction) — framed as the 2026 student finally finishing the book in the library, now understanding the footnotes | No gameplay — cinematic/reading epilogue, transitions to Ending screen (Section 17) | **Medal: The Illustrado** |

---

## 9. STORY DESIGN — TONE-SHIFT TECHNIQUE (Noli → Fili)

Mechanically encode the novels' own thematic pivot (reform → accelerationism):
- **Palette:** Noli areas are warm/golden (hope); Fili areas desaturate, more blue/grey, harsher shadows.
- **Music:** Noli's main motif is major-key kundiman-inspired; the *same* motif returns in Fili transposed to minor key.
- **UI chrome:** Journal paper texture ages/yellows between arcs.
- **Mini-game framing:** Noli puzzles are framed as "help/build" (assemble the school cornerstone plaque); Fili puzzles are framed as "uncover/expose" (assemble the truth behind a bombing plot).
- **NPC callback system:** Every named Fili-arc NPC who appeared as a background sprite in Noli (a student who is now Isagani's classmate, a merchant who is now Quiroga's clerk) should be flagged in the Codex as a "Then and Now" pair — a very Pokémon-esque "you caught this one before it evolved" dopamine hit, done here through recognition rather than stat growth.

---

## 10. QUEST DESIGN

**Four quest types**, each following this template:

```
Quest ID / Title
Type: Main | Side | Knowledge | Collectible
Story Purpose: (why this exists narratively)
Learning Objective: (the one historical fact/theme it's built to teach)
NPC(s) Involved:
Trigger: (where/when it becomes available)
Objectives: (numbered, player-facing)
Completion Requirement:
Rewards: (Knowledge XP, Codex unlock, cosmetic, Journal entry)
Historical Explanation: (the footnote shown on completion)
Dialogue Sample: (2–4 lines, see Section 12 for full dialogue rules)
```

**Worked example (Side Quest, Chapter 3):**
```
Quest ID: SQ-03-02 "What Tasyo Reads at Night"
Type: Side Quest
Story Purpose: Deepen the player's understanding of why Pilosopo Tasyo
  is dismissed as "loco" by San Diego's townsfolk.
Learning Objective: 19th-century Filipino ilustrados' access to banned
  European Enlightenment texts, and the social cost of intellectualism
  under a friar-controlled information environment.
NPC(s) Involved: Pilosopo Tasyo, two gossiping market vendors (invented)
Trigger: After first entering San Diego town plaza in Chapter 3
Objectives:
  1. Overhear two vendors gossiping about "the old fool's books"
  2. Visit Tasyo's hut and ask about his library
  3. Choose a dialogue branch: ask about a specific banned book
     (cosmetic-only branching — all paths lead to same unlock)
Completion Requirement: Complete the 3 objectives above
Rewards: +40 Knowledge XP, Codex unlock "Pilosopo Tasyo — full bio,"
  Journal entry "The Loneliest Library in San Diego"
Historical Explanation: Short footnote on real ilustrados (e.g. the
  Propaganda Movement figures Rizal was writing for/about) and how
  owning certain books was itself politically dangerous.
```

Sample counts to actually build for MVP: **7 Main Quests** (one per Noli chapter minimum, expand for Fili), **~20 Side Quests**, **~15 Knowledge Quests** (pure Codex/lore digs, no combat-adjacent mechanic at all), **~30 Collectibles** (found letters, pressed flowers from Maria Clara's garden, old coins, etc. — see Section 15 Codex "Artifacts" category).

---

## 11. DIALOGUE SYSTEM

- **Branching but non-lethal to progress:** every branch is flavor/characterization, never a fail-state. This keeps the "witness, don't rewrite" pillar intact while still giving Pokémon-style dialogue-choice satisfaction.
- **Two dialogue registers, togglable in Settings:** (a) Filipino-flavored English (period-appropriate but readable — "Salamat, iho, but I must speak with your father first"), and (b) a Tagalog-primary mode for classroom use. Never machine-translate; write both natively.
- **Speech bubble rules borrowed from Pokémon:** portrait bust on one side, name plate, A-to-advance, hold-to-fast-forward, auto-log every line to the Journal.
- **Historical figures' dialogue is paraphrase-bounded:** no invented dialogue is ever presented as a *direct quote* from Rizal's actual biography (only the novel's fictional characters get full invented dialogue, since they're already fictional).

---

## 12. PLAYER PROGRESSION — KNOWLEDGE XP & RANKS

| Rank | XP Threshold (suggested) | Unlocks |
|---|---|---|
| Reader | 0 | Journal, basic Codex tab |
| Student | 500 | Codex "Vocabulary" tab, hint tokens purchasable |
| Scholar | 1,500 | Codex "Historical Terms" + "Timeline" tabs, harder optional quiz variant |
| Historian | 3,500 | Codex "Artifacts" tab, developer-commentary-style bonus footnotes |
| Illustrado | 6,000 (~100% main story) | Full Codex, Ending "Certificate," New Game+ with a "Historian Mode" (extra primary-source excerpts, properly short/paraphrased per Section 21's copyright rule) |

XP sources: quiz correctness (small, since we don't want test-anxiety to be the main driver), **first-time discovery** of a location/NPC/item (large — rewards curiosity, Pokémon-Dex-style), quest completion (medium), Journal reflection entries where the player writes 1–2 sentences in their own words (bonus XP, optional, never required — light UGC hook).

---

## 13. GAME ECONOMY

No numeric "gold" grind. A single soft currency, **Sipat** (roughly "insight/observation" in Filipino), earned from Knowledge Quests and Codex completion %, spendable at the Bookstore on **cosmetic-only** items: period-appropriate outfit recolors, journal stickers/wax seals, cosmetic pets (a Golden Retriever... no — a period-correct carabao or a pet turtle following the player), and hint tokens (reveal one puzzle step). Nothing is pay-to-win because nothing is competitive.

---

## 14. UI FLOW (WIREFRAME NOTES)

```
[Title Screen] → [New/Continue/Settings/Credits]
      │
      ▼ (New Game)
[Name & Pronoun Picker] → [Dialogue Tone Picker: Curious/Skeptical/Dismissive]
      │
      ▼
[Prologue cutscene, non-skippable first playthrough]
      │
      ▼
┌─────────────── IN-GAME HUD (always-on, minimal) ───────────────┐
│  [Chapter Medal count]   [Knowledge XP bar]   [Menu icon]        │
└──────────────────────────────────────────────────────────────────┘
      │ (press Menu)
      ▼
┌──────────────── PAUSE MENU (Pokémon-style radial/list) ─────────┐
│  Journal | Codex | Achievements | Save | Settings | Quit         │
└──────────────────────────────────────────────────────────────────┘
```
- **Journal:** chronological scrollback, auto-written, filterable by chapter.
- **Codex:** grid of silhouette-locked/unlocked entries, tabs = Characters / Locations / Terms / Books & Letters / Events / Timeline / Artifacts / Vocabulary (per the original spec's "Everything unlocks progressively").
- **Quiz Modal:** appears end-of-chapter, framed as "Journal Recap — how much do YOU remember?", 2–4 questions, immediate soft feedback (no "WRONG" buzzer — instead "Here's what actually happened:" + footnote).

---

## 15. RIZAL CODEX — SEED DATA (real entries to ship at launch, not placeholders)

**Characters tab** (minimum launch set, each needs: portrait, 2–3 sentence bio, "first encountered" chapter tag, relationships web):
Crisóstomo Ibarra / Simoun, Maria Clara, Elias, Padre Dámaso, Padre Salví, Capitán Tiago, Sisa, Basilio, Crispin, Pilosopo Tasyo, Doña Victorina, Don Tiburcio, Lt. Guevara, Cabesang Tales, Tandang Selo, Juli, Isagani, Paulita Gomez, Padre Florentino, Padre Camorra (handled per Section 21), Don Custodio, Ben-Zayb, Quiroga.

**Locations tab:** San Diego town plaza, San Diego church & convent, Laguna de Bay, Ibarra family tomb (forest), the steamship Tabo, University of Santo Tomas, Quiapo Fair, Padre Florentino's coastal estate.

**Historical Terms tab:** *ilustrado, principalía, friarocracy, Propaganda Movement, Katipunan* (referenced only, since it postdates the novels' setting but is essential context), *Guardia Civil*, *encomienda*-adjacent land-rent abuses (as dramatized via Cabesang Tales).

**Books & Letters tab:** in-fiction letters (Ibarra's letters to Maria Clara), plus real-world companion entries on *Noli Me Tangere* and *El Filibusterismo* themselves as published objects (dates, dedications, publication cities — Berlin 1887, Ghent 1891).

**Timeline tab:** a real chronological line from 1861 (Rizal's birth) through 1896 (execution), letting the player see where the *fictional* novel's 1887/1891 setting sits inside the *real* biography — this is the single best "aha" unlock in the whole Codex and should be teased early, fully unlocked only at the Epilogue.

**Artifacts tab:** collectible items (Maria Clara's locket, Elias's grandfather's ledger page, a pressed sampaguita, a cracked terracotta jar) tied to Collectible-type quests.

---

## 16. JOURNAL

Auto-writes in first person ("Today I watched Ibarra..."), one entry per major beat, editable by the player only in the optional bonus-XP reflection field (Section 12). Chapter-end auto-summaries roll multiple entries into a one-paragraph recap for the Ending's "Timeline Review."

---

## 17. SAVE SYSTEM

- Manual save at any Library/Archive/Convent checkpoint.
- Autosave on every chapter-end Medal award.
- Checkpoint save immediately before any non-skippable cutscene (in case of app crash/close).
- 3 save slots, each showing: chapter, % Codex complete, % Achievements complete, playtime, last-seen location thumbnail.
- Data model given in Section 19 (Postgres schema) — saves are server-synced when logged in (JWT), with a local-storage-free browser fallback for anonymous play (per this environment's own storage rules, the *shipped* game's backend Postgres is the real persistence layer — not localStorage).

---

## 18. ACHIEVEMENTS (sample set, expand freely)

"The Listener" (talk to every NPC in Ch.1) · "Empty-Handed" (finish Noli without missing a single Collectible) · "Then and Now" (identify all Fili "callback" NPCs) · "Footnote Reader" (open 100% of historical pop-ups rather than skipping) · "The Long Silence" (complete the interstitial without skipping dialogue) · "Illustrado" (100% Codex).

---

## 19. TECHNICAL RECOMMENDATIONS

```
ph-history-game/
├── client/                       React + TS + Vite host shell
│   ├── src/
│   │   ├── game/                 Phaser 3 lives here
│   │   │   ├── config.ts
│   │   │   ├── scenes/           BootScene, PrologueScene, TownScene, ...
│   │   │   └── data/             codex.ts, chapters.ts, quests.ts (typed content)
│   │   ├── ui/                   React overlay: HUD, Codex, Journal, Quiz, Dialogue
│   │   └── styles/
│   └── public/assets/            sprites/ tilesets/ audio/ ui/  ← Carl's Drive assets go here
├── server/                       Node + Express + TS
│   ├── src/
│   │   ├── db/                   schema.sql, pool.ts
│   │   ├── routes/                auth.ts, progress.ts, codex.ts
│   │   ├── middleware/            auth.ts (JWT verify)
│   │   └── models/
│   └── .env.example
└── README.md
```

- **State bridge:** Phaser scenes emit events (`game.events.emit('codex:unlock', id)`); a thin React context subscribes and re-renders overlay UI — avoids fighting Phaser's own render loop with React reconciliation.
- **Content-as-data:** chapters/quests/codex are typed TS objects (not hardcoded in scene logic) so writers can add content without touching engine code — this is the single highest-leverage architecture decision for a 150–300-"page" scope project, because it lets the GDD's prose (this very document) become literal source data.
- **Auth:** JWT access + refresh token pair; Postgres `users`, `save_slots`, `codex_progress`, `journal_entries`, `achievements` tables (starter schema included in the scaffold below).
- **Testing priority order for an MVP:** Prologue → Chapter 1 → save/load round-trip → Codex unlock pipeline → repeat for remaining chapters. Do not build all 11 chapters' scenes before validating this pipeline once.

---

## 20. MINI-GAMES (mechanic spec, one per type)

| Mini-game | Mechanic | Used in |
|---|---|---|
| Timeline Arrangement | Drag real/fictional events into correct order on a rope-and-clothespin UI | Ch.10 (Tales' fall), Epilogue |
| Hidden Objects | Parallax scene, tap/click sprites hidden in foreground clutter | Maria Clara's garden, Tasyo's hut |
| Letter Assembly | Drag torn paper fragments to reconstruct a document | Ch.6 frame-up evidence, Ch.9 posters |
| Book Matching | Memory-match author quotes/portraits to correct book (light, not verbatim-reproduction — summarized blurbs only, see Section 21) | Bookstore side-content |
| Dialogue Choices | Branching, cosmetic-only (Section 11) | Every NPC conversation |
| Memory Matching | Classic face-down pairs, themed to Codex portraits | Bookstore minigame corner |
| Translation | Tagalog↔Spanish-loanword matching (light language-history lesson) | UST classroom scenes |
| Historical Investigation | Multi-clue deduction board (a light "Ace Attorney" board, no accusation-fail state — just reveals the truth once enough clues are found) | Ch.2, Ch.6 |
| Reading Challenge | Timed but low-pressure paragraph-comprehension check, always paraphrased text (never a lengthy verbatim reproduction) | Optional Scholar-rank bonus content |

---

## 21. HISTORICAL ACCURACY & CONTENT-SENSITIVITY NOTES

The source novels contain domestic abuse, wrongful imprisonment, torture, exhumation, a child's beating, a mother's descent into madness, execution, attempted/implied sexual assault (Padre Camorra toward Juli), and suicide (Juli's death, Maria Clara's threatened death). Given the likely player age range (Section 3 includes Grade 9–10 students), the build should:

- **Depict consequences, not mechanics.** Sisa's madness, Juli's death, and Elias's death are shown through **aftermath, framing, and dialogue**, never through graphic on-screen depiction of the act itself. Use screen-fades, off-screen sound design, and NPC reaction shots — the same technique the *novel itself* often uses (Rizal narrates around the worst moments too).
- **No interactive self-harm or violence mechanics.** These sequences are cutscene-only; the player never presses a button that "does" the harmful act.
- **Padre Camorra's predation is referenced, never staged.** Keep it at the level the Codex/Journal would record historically ("a friar known for pursuing local women forced Juli to make an impossible choice") without depicting the confrontation.
- **Quotations stay short and are legally/ethically safe.** Elias's famous last line and any other line from the novels used in-game should be **paraphrased** in original game dialogue rather than reproduced verbatim at length, both because these are literary works still under a publisher's edition copyright in translation and because paraphrase is simply better game-writing (it's an interactive medium, not a book excerpt viewer).
- **Historical figures vs. fictional figures stay clearly separated in the Codex UI** (e.g., a small "Fictional character created by Rizal" vs. "Historical figure" tag on every entry) — this single UI tag does a huge amount of the game's actual *educational* labor, since student confusion between the two is the #1 real-world misconception the game should correct.

---

## 22. ASSET PIPELINE

- **Art direction:** GBA/NDS-era pixel art, ~32×32 or 48×48 character tiles (match whichever your existing Drive assets already use — audit first, see Section 24 Step 0), painterly cutscene stills for the big non-interactive beats (Elias's death, the lamp explosion, Rizal's execution) rather than trying to pixel-animate them.
- **Palette:** warm ilustrado-era sepia/gold for Noli, cooling to steel-blue/verdigris for Fili (ties to Section 9).
- **Audio:** kundiman-inspired original motifs; period rondalla instrumentation (bandurria, laúd) for town themes; sparse, low string drone for Fili's tension beats.
- **Asset folder contract** (so existing Drive assets slot in with zero renaming): `public/assets/sprites/characters/`, `.../tilesets/`, `.../audio/bgm/`, `.../audio/sfx/`, `.../ui/`. Whatever's already in the Drive folder should mirror this shape — audit it against this contract before the next build session.

---

## 23. PRODUCTION ROADMAP

| Phase | Scope | Exit criteria |
|---|---|---|
| 0 — Foundation (this session) | Repo scaffold, Prologue scene playable, save/load round-trip, Codex data pipeline | `npm run dev` shows Prologue → wake-up-in-1887 transition |
| 1 — Noli Vertical Slice | Chapters 1–3 fully playable, 1 mini-game type wired, quiz flow, first Chapter Medal | A stranger could play 20 minutes start-to-finish |
| 2 — Noli Complete | Chapters 4–7, all Noli Codex entries, Achievements v1 | Full Noli arc playable, Elias's death lands emotionally |
| 3 — Interstitial + Fili Vertical Slice | Time-skip, Ch.8–9 | Tone-shift (Section 9) verifiably readable in a playtest |
| 4 — Fili Complete + Ending | Ch.10–11, Epilogue, Ending screen (Timeline Review, Codex %, Certificate) | Full game completable start-to-finish |
| 5 — Polish & Accessibility | Audio pass, difficulty/hint tuning, mobile input pass | Ready for a public/classroom pilot |

---

## 24. IMMEDIATE NEXT STEPS (for whoever/whatever builds this next)

0. **Audit the existing Drive asset folder** against Section 22's folder contract before writing new scene code that assumes placeholder art.
1. Wire real sprites into the scaffold's placeholder rectangles (see the delivered code — it renders colored rectangles with labels where art goes, on purpose, so nothing blocks on missing assets).
2. Fill out `chapters.ts`/`quests.ts`/`codex.ts` chapter-by-chapter following Sections 8/10/15 above — they're already typed and partially seeded in the scaffold.
3. Stand up Postgres locally (`schema.sql` provided), confirm the JWT auth round-trip, then move to Phase 1 of the roadmap.

---

## 25. FUTURE EXPANSION IDEAS

- **Teacher Dashboard:** a lightweight web view (reuses the same Postgres/JWT backend) where a teacher account sees aggregate Codex completion / quiz accuracy per class — turns the game into an assignable classroom tool, which is a strong distribution channel for a Philippine-history game.
- **"Mi Ultimo Adios" epilogue DLC:** a short, entirely non-interactive, beautifully art-directed reading-mode chapter built around Rizal's real farewell poem (paraphrased/contextualized, never reproduced at full length per Section 21) as a premium free content-drop around every December 30 (Rizal Day).
- **Other Ilustrados mode:** small side-episodes about Marcelo del Pilar, Graciano López Jaena, or the Gomburza priests, reusing the same engine/Codex systems.
- **New Game+ "Historian Mode":** unlocks longer primary-source excerpts (properly licensed/paraphrased), developer commentary, and a harder investigation-board difficulty.
