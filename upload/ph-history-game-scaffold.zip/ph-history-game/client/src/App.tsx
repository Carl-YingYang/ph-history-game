import { useEffect, useRef, useState } from 'react';
import Phaser from 'phaser';
import { createGameConfig, GameEvents } from './game/config';
import { HUD } from './ui/HUD';
import { DialogueBox } from './ui/DialogueBox';
import { CodexPanel } from './ui/CodexPanel';
import { JournalPanel } from './ui/JournalPanel';
import './styles/theme.css';

type PanelName = 'none' | 'codex' | 'journal';

export default function App() {
  const gameParentRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Phaser.Game | null>(null);

  const [knowledgeXp, setKnowledgeXp] = useState(0);
  const [medalCount, setMedalCount] = useState(0);
  const [unlockedCodexIds, setUnlockedCodexIds] = useState<Set<string>>(new Set());
  const [journalEntries, setJournalEntries] = useState<{ text: string; timestamp: number }[]>([]);
  const [dialogue, setDialogue] = useState<{ speaker: string; line: string } | null>(null);
  const [activePanel, setActivePanel] = useState<PanelName>('none');

  useEffect(() => {
    if (!gameParentRef.current || gameRef.current) return;

    const game = new Phaser.Game(createGameConfig(gameParentRef.current));
    gameRef.current = game;

    game.events.on(GameEvents.KnowledgeXp, ({ amount }: { amount: number }) => {
      setKnowledgeXp((xp) => xp + amount);
    });

    game.events.on(GameEvents.ChapterMedal, () => {
      setMedalCount((c) => c + 1);
    });

    game.events.on(GameEvents.CodexUnlock, ({ id }: { id: string }) => {
      setUnlockedCodexIds((prev) => new Set(prev).add(id));
    });

    game.events.on(GameEvents.JournalEntry, ({ text }: { text: string }) => {
      setJournalEntries((entries) => [...entries, { text, timestamp: Date.now() }]);
    });

    game.events.on(GameEvents.DialogueLine, (payload: { speaker: string; line: string }) => {
      setDialogue(payload);
      window.setTimeout(() => setDialogue(null), 4000);
    });

    return () => {
      game.destroy(true);
      gameRef.current = null;
    };
  }, []);

  const rank =
    knowledgeXp >= 6000 ? 'Illustrado' : knowledgeXp >= 3500 ? 'Historian' : knowledgeXp >= 1500 ? 'Scholar' : knowledgeXp >= 500 ? 'Student' : 'Reader';

  return (
    <div className="noor-app">
      <HUD knowledgeXp={knowledgeXp} rank={rank} medalCount={medalCount} onOpenMenu={() => setActivePanel('journal')} />
      <div ref={gameParentRef} />
      {dialogue && <DialogueBox speaker={dialogue.speaker} line={dialogue.line} />}

      <div style={{ display: 'flex', gap: 8 }}>
        <button className="noor-button" onClick={() => setActivePanel('journal')}>
          Journal
        </button>
        <button className="noor-button" onClick={() => setActivePanel('codex')}>
          Codex
        </button>
      </div>

      {activePanel === 'codex' && <CodexPanel unlockedIds={unlockedCodexIds} onClose={() => setActivePanel('none')} />}
      {activePanel === 'journal' && <JournalPanel entries={journalEntries} onClose={() => setActivePanel('none')} />}
    </div>
  );
}
