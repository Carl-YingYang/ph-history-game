interface HudProps {
  knowledgeXp: number;
  rank: string;
  medalCount: number;
  onOpenMenu: () => void;
}

export function HUD({ knowledgeXp, rank, medalCount, onOpenMenu }: HudProps) {
  const xpForNextRank = 500; // simplified for the scaffold — see Master Prompt Section 12 for full curve
  const pct = Math.min(100, (knowledgeXp % xpForNextRank) / xpForNextRank * 100);

  return (
    <div className="noor-hud">
      <div>🏅 {medalCount} Medals</div>
      <div>
        {rank} — {knowledgeXp} XP
        <div className="noor-xp-bar">
          <div className="noor-xp-fill" style={{ width: `${pct}%` }} />
        </div>
      </div>
      <button className="noor-button" onClick={onOpenMenu}>
        Menu
      </button>
    </div>
  );
}
